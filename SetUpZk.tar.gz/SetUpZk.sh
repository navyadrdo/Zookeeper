#!/bin/bash




#$ ls -d $PWD/*







if [ "ls | grep  zookeeper" ] ; then
 echo 1
#for i in `seq 5` ; do mkdir -p zk-data/$i ; echo $i>zk-data/$i/myid; done
#for i in `seq 5` ; do mkdir -p config/$i ;  done
#test = $( ls | grep  zookeeper  )


trFile=`ls | grep "zook"`
echo $trFile
 fi 
rm -f startZoo.sh stopZoo.sh
touch startZoo.sh stopZoo.sh

for i in `seq 5` ; 
do 
mkdir -p config/$i ;  
cp "$trFile"/conf/zoo_sample.cfg config/$i/zoo.cfg
mkdir -p zk-data/$i ; echo $i>zk-data/$i/myid;
sed -i "s#/tmp/zookeeper#$PWD/zk-data/$i#g" config/$i/zoo.cfg
sed -i "s#2181#218$i#g" config/$i/zoo.cfg
echo "server.1=localhost:2881:3881 
server.2=localhost:2882:3882 
server.3=localhost:2883:3883 
server.4=localhost:2884:3884
server.5=localhost:2885:3885" >> config/$i/zoo.cfg
echo $trFile/bin/zkServer.sh start config/$i/zoo.cfg >> startZoo.sh
echo $trFile/bin/zkServer.sh stop config/$i/zoo.cfg >> stopZoo.sh
done

chmod +x *.sh

echo $trFile
